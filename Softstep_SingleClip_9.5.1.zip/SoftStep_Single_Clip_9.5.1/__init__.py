#__init__.py
from SoftStep_Single_Clip import SoftStep_Single_Clip
def create_instance(c_instance):
	return SoftStep_Single_Clip(c_instance)